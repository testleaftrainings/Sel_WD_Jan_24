package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;
import pages.LoginPage;

public class Login  extends BaseClass{
	@BeforeTest
	public void setData() {
		 excelFileName="Login";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String Username,String password) {
		//System.out.println();
		new LoginPage()
		.enterUserName(Username)
		.enterPassword(password)
		.clickLoginButton()
		.verifyHomePage();
		
		
//		LoginPage lp=new LoginPage();
//		lp.enterUserName()
//		
//		.enterPassword()
//		.clickLoginButton()
//		.verifyHomePage();
		
		
		
	}
}
