package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utills.ReadExcel;



public class BaseClass extends AbstractTestNGCucumberTests{
	
	
private static final ThreadLocal<RemoteWebDriver> remoteWebDriver=new ThreadLocal<RemoteWebDriver>();
	
	public void setDriver() {
		remoteWebDriver.set(new ChromeDriver());
	}
	
	public RemoteWebDriver getDriver() {
		 return remoteWebDriver.get();
	}
	//public  ChromeDriver driver;
	public String excelFileName;
	
	@DataProvider(name="fetchData")
	 public String[][] sendData() throws IOException {
		 ReadExcel excel=new ReadExcel();
		 String[][] data = excel.excelData(excelFileName);
		 return data;
		
	 }
	
	@BeforeMethod
	public void preCondition(){
		 setDriver();  //driver = new ChromeDriver();
		 getDriver().manage().window().maximize();
		 getDriver().get("http://leaftaps.com/opentaps/control/main");
		 getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}

    @AfterMethod
	public void postCondition(){
    	getDriver().close();
	}
}
