package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomePage extends BaseClass {

	
	public LoginPage clickLogout() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new LoginPage();
	}

	@When("Click on crmsfa link")
	public MyHomePage clickCrmsfaLink() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
    return new MyHomePage();
	}
	
	@Then("Homepage should be displayed")
	public void verifyHomePage() {
		String text = getDriver().findElement(By.tagName("h2")).getText();
		System.out.println(text);
	}
}
