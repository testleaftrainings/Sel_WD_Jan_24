package pages;

import base.BaseClass;

public class ViewLeadPage extends BaseClass {

}
