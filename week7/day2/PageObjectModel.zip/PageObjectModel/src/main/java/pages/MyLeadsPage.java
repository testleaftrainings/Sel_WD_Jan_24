package pages;

import base.BaseClass;

public class MyLeadsPage extends BaseClass{

}
