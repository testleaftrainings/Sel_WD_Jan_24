package pages;

import base.BaseClass;

public class CreateLeadPage extends BaseClass{

}
