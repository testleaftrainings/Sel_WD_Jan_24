package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class HomePage extends BaseClass {

	
	public LoginPage clickLogout() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new LoginPage();
	}

	public MyHomePage clickCrmsfaLink() {
		driver.findElement(By.linkText("CRM/SFA")).click();
    return new MyHomePage();
	}
	
	public void verifyHomePage() throws IOException {
		try {
			String text = driver.findElement(By.tagName("h2")).getText();
			System.out.println(text);
			reportStep("Homepage successfully  displayed", "pass");
		} catch (Exception e) {
			reportStep("Homepage successfully not  displayed  "+e , "fail");
		}
	}
}
