package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class LoginPage extends BaseClass{
// we have to receiev driver instance
	
	
	public LoginPage enterUserName(String userName) throws IOException  {//prop.getProperty("userName")
		try {
			driver.findElement(By.id("username")).sendKeys(userName);
			reportStep("UserName Entered Successfully", "pass");
		} catch (Exception e) {
			reportStep("UserName not Entered Successfully    "+e, "fail");
		}
  //   LoginPage lp=new LoginPage();
     return this;
	}
	public LoginPage enterPassword(String password) throws IOException  {
		try {
			driver.findElement(By.id("password")).sendKeys(password);
			reportStep("Password Entered Successfully", "pass");
		} catch (Exception e) {
			reportStep("Password not Entered Successfully   "+e, "fail");
		}
		return this;
	}
	public HomePage clickLoginButton() throws IOException  {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("Login Button clicked  Successfully", "pass");
		} catch (Exception e) {
			reportStep("Login Button not  clicked  Successfully  "+e, "fail");
		}
     
   
   //  HomePage hp=new HomePage();
     return new HomePage();
	}

}
