package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utills.ReadExcel;



public class BaseClass {



	public  static ChromeDriver driver;
	public String excelFileName;
	public static ExtentReports extent;
	public static ExtentTest test;
	public String testcaseName,testDescription,category,author;

	@BeforeSuite
	public void startReporter() {
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent=new ExtentReports();
		extent.attachReporter(reporter);
	}

	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testcaseName,testDescription);
		test.assignCategory(category);
		test.assignAuthor(author);
	}
  
	public void reportStep(String stepInfo,String status) throws IOException {
		int randomSnapshot = takeSnap();
		if(status.equalsIgnoreCase("pass")) {
			test.pass(stepInfo,MediaEntityBuilder.createScreenCaptureFromPath(".././snap/img"+randomSnapshot+".png").build());
		}else if (status.equalsIgnoreCase("fail")) {
			test.fail(stepInfo,MediaEntityBuilder.createScreenCaptureFromPath(".././snap/img"+randomSnapshot+".png").build());
		   throw new RuntimeException("see the ExtentReports for more Details");
		}
	}

	public int takeSnap() throws IOException {
		
		int number= (int) (Math.random() * 999999+1000000);
		File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
		File destination=new File("./snap/img"+number+".png");
		FileUtils.copyFile(screenshotAs, destination);
		return number;
	}


	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
		ReadExcel excel=new ReadExcel();
		String[][] data = excel.excelData(excelFileName);
		return data;

	}
	
	@BeforeMethod
	public void preCondition() throws IOException{
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}

	@AfterMethod
	public void postCondition(){
		driver.close();
	}
	
	@AfterSuite
	public void endReport() {
		extent.flush();
	}
}
