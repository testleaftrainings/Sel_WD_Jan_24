package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;
import pages.LoginPage;

public class Login  extends BaseClass{
	@BeforeTest
	public void setData() {
		 excelFileName="Login";
		 testcaseName="Login";
		 testDescription="Login with valid credentials";
		 category="smoke";
		 author="Aravind";
		 
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String userName,String password) throws IOException {
		System.out.println(driver);
		new LoginPage()
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton()
		.verifyHomePage();
		
		
//		LoginPage lp=new LoginPage();
//		lp.enterUserName()
//		
//		.enterPassword()
//		.clickLoginButton()
//		.verifyHomePage();
		
		
		
	}
}
