package sample;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {
	public static void main(String[] args) throws IOException {

		//Step1: Setup the physical reporter path
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/result.html");

         // i want to store history
		reporter.setAppendExisting(true);
		//Step2: Create a object for ExtentReports
		ExtentReports extent=new ExtentReports();


		//step3: Attache the data with physical file 
		extent.attachReporter(reporter);

		//Step4: Create a testcases and assign the test details

		ExtentTest test = extent.createTest("CreateLead", "CreateLead with mandatory field");

		test.assignCategory("Smoke");

		test.assignAuthor("Aravind");


                                                                                                    //To come out of reports folder
		//step5: step level details
		test.pass("Enter the userName as Demosalesmanager",MediaEntityBuilder.createScreenCaptureFromPath(".././snap/CreateLead.png").build());

		test.pass("Enter the password as crmsfa");

		test.pass("Click on Login Button");

		ExtentTest test2 = extent.createTest("CreateLead", "CreateLead with mandatory field");

		test2.assignCategory("Sanity");

		test2.assignAuthor("Raghu");
		//step5: step level details
		test2.pass("Enter the userName as Demosalesmanager");

		test2.pass("Enter the password as crmsfa");

		test2.pass("Click on Login Button");


		//Stpe6: Mandatory step or method
		extent.flush();






	}
}
