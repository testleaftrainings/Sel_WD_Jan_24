package learnpropertyfile;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnToReadTheDataFromPropertyFile {

	public static void main(String[] args) throws IOException {

		//set up the file path
		FileInputStream fis=new FileInputStream("src/main/resources/config.properties");

		//Create object for Property file
		Properties prop=new Properties();

		//Load the property file
		prop.load(fis);

		String property = prop.getProperty("url");

		System.out.println(property);

		String property1 = prop.getProperty("userName");

		System.out.println(property1);

		String property2 = prop.getProperty("password");

		System.out.println(property2);

		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(prop.getProperty("url"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.id("username")).sendKeys(prop.getProperty("userName"));
		driver.findElement(By.id("password")).sendKeys(prop.getProperty("password"));
		driver.findElement(By.className("decorativeSubmit")).click();








	}
}
