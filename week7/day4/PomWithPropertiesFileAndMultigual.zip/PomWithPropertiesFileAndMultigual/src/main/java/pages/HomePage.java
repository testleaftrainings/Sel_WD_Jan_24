package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class HomePage extends BaseClass {

	
	public LoginPage clickLogout() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new LoginPage();
	}

	public MyHomePage clickCrmsfaLink() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
    return new MyHomePage();
	}
	
	public void verifyHomePage() {
		String text =  getDriver().findElement(By.tagName("h2")).getText();
		System.out.println(text);
	}
}
