package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import utills.ReadExcel;



public class BaseClass {
private static final ThreadLocal<RemoteWebDriver> remoteWebDriver=new ThreadLocal<RemoteWebDriver>();
	
	
	public void setDriver() {
		remoteWebDriver.set(new ChromeDriver());
	}
	
	public RemoteWebDriver getDriver() {
		return remoteWebDriver.get();
	}
	
	
	
	//public  ChromeDriver driver;
	public String excelFileName;
	
	@DataProvider(name="fetchData")
	 public String[][] sendData() throws IOException {
		 ReadExcel excel=new ReadExcel();
		 String[][] data = excel.excelData(excelFileName);
		 return data;
		
	 }
	public static Properties prop;
	@Parameters("language")
	
	@BeforeMethod
	public void preCondition(String lang) throws IOException{
		if(lang.equals("English")) {
			FileInputStream  fis=new FileInputStream("src/main/resources/config_english.properties");
		    prop=new Properties();
			prop.load(fis);
		}else if (lang.equals("French")) {
			FileInputStream  fis=new FileInputStream("src/main/resources/config_french.properties");
		    prop=new Properties();
			prop.load(fis);
		}
  setDriver();
	     //driver = new ChromeDriver();
	     getDriver().manage().window().maximize();
	     getDriver().get(prop.getProperty("url"));
	     getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}

    @AfterMethod
	public void postCondition(){
    	 getDriver().close();
	}
}
