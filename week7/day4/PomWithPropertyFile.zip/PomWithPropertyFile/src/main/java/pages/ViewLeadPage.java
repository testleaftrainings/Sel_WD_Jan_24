package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class ViewLeadPage extends BaseClass {
	
	
  	public void verifyViewLeadsPage() {
  		String actualResult="View Lead | opentaps CRM";
  		String expectedResult = driver.getTitle();
  		if(expectedResult.equals(actualResult)) {
  			System.out.println("ViewLead Page displayed successfully");
  		}else {
  			System.out.println("ViewLead Page not displayed");
  		}

  	}

}
