package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import utills.ReadExcel;



public class BaseClass {

	
	
	public  static ChromeDriver driver;
	public String excelFileName;
	
	@DataProvider(name="fetchData")
	 public String[][] sendData() throws IOException {
		 ReadExcel excel=new ReadExcel();
		 String[][] data = excel.excelData(excelFileName);
		 return data;
		
	 }
	public static Properties prop;
	//public  FileInputStream fis;
	@BeforeMethod
	public void preCondition() throws IOException{
		FileInputStream  fis=new FileInputStream("./src/main/resources/config.properties");
	    prop=new Properties();
		prop.load(fis);
	    driver = new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.get(prop.getProperty("url"));
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}

    @AfterMethod
	public void postCondition(){
    	driver.close();
	}
}
