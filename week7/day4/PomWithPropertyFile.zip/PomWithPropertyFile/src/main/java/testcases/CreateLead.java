package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;
import pages.LoginPage;

public class CreateLead  extends BaseClass{

	@BeforeTest
	public void setData() {
		 excelFileName="CreateLead";
	}

	@Test(dataProvider = "fetchData")
	public void runLogin(String companyName,String firstName,String lastName) {
		System.out.println(driver);
		new LoginPage()
		.enterUserName()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsTap()
		.clickcreateLeadTap()
		.enterCompanyName(companyName)
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.clickCreateLeadButton()
		.verifyViewLeadsPage();
		
		
//		LoginPage lp=new LoginPage();
//		lp.enterUserName()
//		
//		.enterPassword()
//		.clickLoginButton()
//		.verifyHomePage();
		
		
		
	}
}
